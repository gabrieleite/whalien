function Enviar() {

    var nome = document.getElementById("nomeid");

    if (nome.value != "") {
        alert('Olá ' + nome.value + ' sua reserva foi realizada com sucesso!!');
    }

}